<?php
namespace RedCraftPE\RedSkyBlock\Commands\SubCommands;

use pocketmine\utils\TextFormat;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\item\Item;

use RedCraftPE\RedSkyBlock\SkyBlock;
use RedCraftPE\RedSkyBlock\Tasks\Generate;
use RedCraftPE\RedSkyBlock\Commands\Island;

class Create {

  private static $instance;

  public function __construct() {

    self::$instance = $this;
  }

  public function onCreateCommand(CommandSender $sender): bool {
  	$this->Prefix = SkyBlock::getInstance()->Prefix;

    if ($sender->hasPermission("skyblock.create")) {

      $interval = SkyBlock::getInstance()->cfg->get("Interval");
      $itemsArray = SkyBlock::getInstance()->cfg->get("Starting Items", []);
      $levelName = SkyBlock::getInstance()->cfg->get("SkyBlockWorld");
      $skyblockArray = SkyBlock::getInstance()->skyblock->get("SkyBlock", []);
      $islands = SkyBlock::getInstance()->skyblock->get("Islands");
      $initialSize = SkyBlock::getInstance()->cfg->get("Island Size");
      $senderName = strtolower($sender->getName());
      $level = null;
      if ($levelName === "") {

        $sender->sendMessage($this->Prefix."§cBạn phải thiết lập thế giới SkyBlock để plugin này hoạt động bình thường.");
        return true;
      } else {

        if (SkyBlock::getInstance()->getServer()->isLevelLoaded($levelName)) {

          $level = SkyBlock::getInstance()->getServer()->getLevelByName($levelName);
        } else {

          if (SkyBlock::getInstance()->getServer()->loadLevel($levelName)) {

            SkyBlock::getInstance()->getServer()->loadLevel($levelName);
            $level = SkyBlock::getInstance()->getServer()->getLevelByName($levelName);
          } else {

            $sender->sendMessage($this->Prefix."§cThế giới hiện được đặt là thế giới SkyBlock không tồn tại.");
            return true;
          }
        }
      }
      if (array_key_exists($senderName, $skyblockArray)) {

        SkyBlock::getInstance()->getServer()->getCommandMap()->dispatch($sender, "is go");
        return true;
      } else {

        if (SkyBlock::getInstance()->skyblock->get("Custom")) {

          $sender->teleport(new Position($islands * $interval + SkyBlock::getInstance()->skyblock->get("CustomX"), 15 + SkyBlock::getInstance()->skyblock->get("CustomY"), $islands * $interval + SkyBlock::getInstance()->skyblock->get("CustomZ"), $level));
        } else {

          $sender->teleport(new Position($islands * $interval + 2, 15 + 3, $islands * $interval + 4, $level));
        }
        $sender->setImmobile(true);
        SkyBlock::getInstance()->getScheduler()->scheduleDelayedTask(new Generate($islands, $level, $interval, $sender), 10);

        foreach($itemsArray as $items) {

          if (count($itemsArray) > 0) {

            $itemArray = explode(" ", $items);
            if (count($itemArray) === 3) {

              $id = intval($itemArray[0]);
              $damage = intval($itemArray[1]);
              $count = intval($itemArray[2]);
              $sender->getInventory()->addItem(Item::get($id, $damage, $count));
            }
          }
        }

        SkyBlock::getInstance()->skyblock->setNested("Islands", $islands + 1);
        $skyblockArray[$senderName] = Array(
          "Name" => "",
          "Members" => [$sender->getName()],
          "Banned" => [],
          "Locked" => false,
          "Value" => 0,
          "Spawn" => Array(
            "X" => $sender->getX(),
            "Y" => $sender->getY(),
            "Z" => $sender->getZ()
          ),
          "Area" => Array(
            "start" => Array(
              "X" => ($islands * $interval + SkyBlock::getInstance()->skyblock->get("CustomX")) - ($initialSize / 2),
              "Y" => 0,
              "Z" => ($islands * $interval + SkyBlock::getInstance()->skyblock->get("CustomZ")) - ($initialSize / 2)
            ),
            "end" => Array(
              "X" => ($islands * $interval + SkyBlock::getInstance()->skyblock->get("CustomX")) + ($initialSize / 2),
              "Y" => 256,
              "Z" => ($islands * $interval + SkyBlock::getInstance()->skyblock->get("CustomZ")) + ($initialSize / 2)
            )
          ),
          "Settings" => Array(
            "Build" => "on",
            "Break" => "on",
            "Pickup" => "on",
            "Anvil" => "on",
            "Chest" => "on",
            "CraftingTable" => "on",
            "Fly" => "on",
            "Hopper" => "on",
            "Brewing" => "on",
            "Beacon" => "on",
            "Buckets" => "on",
            "PVP" => "on",
            "FlintAndSteel" => "on",
            "Furnace" => "on",
            "EnderChest" => "on"
          )
        );
        SkyBlock::getInstance()->skyblock->set("SkyBlock", $skyblockArray);
        SkyBlock::getInstance()->skyblock->save();
        $sender->sendMessage($this->Prefix."§aBạn đã tạo đảo thành công. Đồ đã vào túi đồ của bạn.");
        return true;
      }
    } else {

      $sender->sendMessage($this->Prefix."§cBạn không có quyền để sử dụng lệnh này.");
      return true;
    }
  }
}