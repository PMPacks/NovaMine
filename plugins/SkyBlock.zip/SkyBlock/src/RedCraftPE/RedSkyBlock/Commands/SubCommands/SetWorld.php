<?php

namespace RedCraftPE\RedSkyBlock\Commands\SubCommands;

use pocketmine\utils\TextFormat;
use pocketmine\command\CommandSender;

use RedCraftPE\RedSkyBlock\SkyBlock;
use RedCraftPE\RedSkyBlock\Commands\Island;

class SetWorld {

  private static $instance;

  public function __construct() {

    self::$instance = $this;
  }

  public function onSetWorldCommand(CommandSender $sender): bool {
  	$this->Prefix = SkyBlock::getInstance()->Prefix;

    if ($sender->hasPermission("skyblock.setworld")) {

      $world = $sender->getLevel()->getFolderName();
      SkyBlock::getInstance()->cfg->set("SkyBlockWorld", $world);
      SkyBlock::getInstance()->cfg->save();
      $sender->sendMessage($this->Prefix."§f" . $world . " §ahas been set as the SkyBlock world on this server.");
      return true;
    } else {

      $sender->sendMessage($this->Prefix."§cYou do not have the proper permissions to run this command.");
      return true;
    }
  }
}
